This folder contains three files.
The pfd is contains the overview of the midterm assignment.
The image errorPlot.png shows a plot of n vs error for Monte Carlo integration.  It is also included in the pdf.
The Python script midterm.py is the bulk code that implements Monte Carlo integration with some improvement.  The algorithm is described in detail in the pdf.
To run the pyton script, open it in Spyder and press the green arrow.

Contents:
Assignment_2.pdf    : write up for this assignment
Program.cs          : generates text files with potential and acceleration and then calculates Lagrange points
makePlots.py        : reads output from Program.cs to generate plots
output/             : directory containing output from the C# code

To run the program(s), first open Program.cs in visual studio and run with the green 'start' button.  The code can also be compiled and run with the windows command prompt (there is a C# compiler included in most windows installations).  This will write files to the desktop.  Then the Python script (makePlots.py) can be run in Spyder (again execute with the green 'play' button). This will attempt to read from the desktop as well.
I've included a compiled version of the C# code: homework_two.exe and sample output from that executabl in ./output/

Folder contains:
assignment_4_ODEs.pdf
hw4_odes.py
a selection of image files (png) which are also embedded in the pdf.

The pdf file is the assignment write-up and a discussion of the graphs generated for the assigment.

The code is a single python script and can bee executed in spyder using the green play button.  Note that the code will attempt to write the plots to a windows desktop directory.  You can change the write location by modifying lines 62, 117, 157, 186, and 289.
